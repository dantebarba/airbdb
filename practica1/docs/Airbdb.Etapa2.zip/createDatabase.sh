mysql -uroot -e "drop database if exists bd2_grupo0; create database bd2_grupo0;"
